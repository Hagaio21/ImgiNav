# ImgiNav - Code Archive 
 
**Generated:** 08-Dec-25 12:21:33.24 
**Source:** C:\Users\Hagai.LAPTOP-QAG9263N\Desktop\Thesis\repositories\ImgiNav 
 
--- 
 
## Summary 
 
| Type | Count | 
|---|---| 
| Python (.py) | 59 | 
| Shell (.sh) | 27 | 
| **Total** | **86** | 
 
## Project Structure 
 
```text 
ImgiNav/ 
    __init__.py 
    checkpoint_registry.py 
    env_config.py 
    file_io.py 
    taxonomy.py 
    utils.py 
    weighting.py 
    __init__.py 
    clean_dataset.py 
    collect_manifest_pov_normalized.py 
    config_loader.py 
    create_shards.py 
    embed_for_training.py 
    embed_layouts_with_vae.py 
    launch_add_rejections_to_manifest.sh 
    launch_clean_dataset.sh 
    launch_clean_dataset_v2.sh 
    launch_pipeline.sh 
    launch_stage4_v2.sh 
    launch_stage5_v2.sh 
    run_clean_dataset.sh 
    run_clean_dataset_v2.sh 
    run_collect_manifest_pov_normalized.sh 
    run_embed_layouts_vae.sh 
    run_embed_pov_normalized.sh 
    run_embeddings.sh 
    run_merge_clean_dataset_v2.sh 
    run_merge_pov_info_shards.sh 
    run_stage2_array.sh 
    run_stage3_array.sh 
    run_stage4_array.sh 
    run_stage4_v2_array.sh 
    run_stage6_array.sh 
    merge_pov_info_shards.py 
    path_utils.py 
    recolor_taxonomy.py 
    stage0_build_taxonomy.py 
    stage0_validate_scenes.py 
    stage1_reconstruct_geometry.py 
    stage2_compile_metadata.py 
    stage3_render_layouts.py 
    stage4_render_povs_v2.py 
    stage6_generate_manifests.py 
    update_manifest_rejections.py 
    visualize_taxonomy_colors.py 
    env_config.sh 
    __init__.py 
    autoencoder.py 
    __init__.py 
    base_component.py 
    base_model.py 
    blocks.py 
    dataflow.py 
    heads.py 
    projections.py 
    registry.py 
    scheduler.py 
    unet.py 
    __init__.py 
    datasets.py 
    decoder.py 
    diffusion.py 
    encoder.py 
    __init__.py 
    base_loss.py 
    clip_loss.py 
    reconstruction_loss.py 
    utils.py 
    clean_layout.py 
    create_occupancy_grid.py 
    diffusion_inference.py 
    navigate.py 
    update_unfinished_list.sh 
    engine.py 
    launch_seg_small_v2.sh 
    launch_seg_small_v2_gpuv100.sh 
    launch_seg_v2_all_9_experiments.sh 
    launch_seg_v2_all_9_wide_shallow_experiments.sh 
    run_train_diff_seg_small_v2.sh 
    run_train_vae_clip_v2.sh 
    metrics_utils.py 
    plotting_utils.py 
    train.py 
    train_clip_projection.py 
    train_diffusion.py 
    utils.py 
``` 
 
## Files 
 
### Python Files 
 
- `common\checkpoint_registry.py` 
- `common\env_config.py` 
- `common\file_io.py` 
- `common\taxonomy.py` 
- `common\utils.py` 
- `common\weighting.py` 
- `common\__init__.py` 
- `data_preparation_v2\clean_dataset.py` 
- `data_preparation_v2\collect_manifest_pov_normalized.py` 
- `data_preparation_v2\config_loader.py` 
- `data_preparation_v2\create_shards.py` 
- `data_preparation_v2\embed_for_training.py` 
- `data_preparation_v2\embed_layouts_with_vae.py` 
- `data_preparation_v2\merge_pov_info_shards.py` 
- `data_preparation_v2\path_utils.py` 
- `data_preparation_v2\recolor_taxonomy.py` 
- `data_preparation_v2\stage0_build_taxonomy.py` 
- `data_preparation_v2\stage0_validate_scenes.py` 
- `data_preparation_v2\stage1_reconstruct_geometry.py` 
- `data_preparation_v2\stage2_compile_metadata.py` 
- `data_preparation_v2\stage3_render_layouts.py` 
- `data_preparation_v2\stage4_render_povs_v2.py` 
- `data_preparation_v2\stage6_generate_manifests.py` 
- `data_preparation_v2\update_manifest_rejections.py` 
- `data_preparation_v2\visualize_taxonomy_colors.py` 
- `data_preparation_v2\__init__.py` 
- `models\autoencoder.py` 
- `models\decoder.py` 
- `models\diffusion.py` 
- `models\encoder.py` 
- `models\utils.py` 
- `models\__init__.py` 
- `models\components\base_component.py` 
- `models\components\base_model.py` 
- `models\components\blocks.py` 
- `models\components\dataflow.py` 
- `models\components\heads.py` 
- `models\components\projections.py` 
- `models\components\registry.py` 
- `models\components\scheduler.py` 
- `models\components\unet.py` 
- `models\components\__init__.py` 
- `models\datasets\datasets.py` 
- `models\datasets\__init__.py` 
- `models\losses\base_loss.py` 
- `models\losses\clip_loss.py` 
- `models\losses\reconstruction_loss.py` 
- `models\losses\__init__.py` 
- `scripts\clean_layout.py` 
- `scripts\create_occupancy_grid.py` 
- `scripts\diffusion_inference.py` 
- `scripts\navigate.py` 
- `training\engine.py` 
- `training\metrics_utils.py` 
- `training\plotting_utils.py` 
- `training\train.py` 
- `training\train_clip_projection.py` 
- `training\train_diffusion.py` 
- `training\utils.py` 
 
### Shell Scripts 
 
- `env_config.sh` 
- `data_preparation_v2\hpc_scripts\launch_add_rejections_to_manifest.sh` 
- `data_preparation_v2\hpc_scripts\launch_clean_dataset.sh` 
- `data_preparation_v2\hpc_scripts\launch_clean_dataset_v2.sh` 
- `data_preparation_v2\hpc_scripts\launch_pipeline.sh` 
- `data_preparation_v2\hpc_scripts\launch_stage4_v2.sh` 
- `data_preparation_v2\hpc_scripts\launch_stage5_v2.sh` 
- `data_preparation_v2\hpc_scripts\run_clean_dataset.sh` 
- `data_preparation_v2\hpc_scripts\run_clean_dataset_v2.sh` 
- `data_preparation_v2\hpc_scripts\run_collect_manifest_pov_normalized.sh` 
- `data_preparation_v2\hpc_scripts\run_embeddings.sh` 
- `data_preparation_v2\hpc_scripts\run_embed_layouts_vae.sh` 
- `data_preparation_v2\hpc_scripts\run_embed_pov_normalized.sh` 
- `data_preparation_v2\hpc_scripts\run_merge_clean_dataset_v2.sh` 
- `data_preparation_v2\hpc_scripts\run_merge_pov_info_shards.sh` 
- `data_preparation_v2\hpc_scripts\run_stage2_array.sh` 
- `data_preparation_v2\hpc_scripts\run_stage3_array.sh` 
- `data_preparation_v2\hpc_scripts\run_stage4_array.sh` 
- `data_preparation_v2\hpc_scripts\run_stage4_v2_array.sh` 
- `data_preparation_v2\hpc_scripts\run_stage6_array.sh` 
- `scripts\update_unfinished_list.sh` 
- `training\hpc_scripts\regular\launch_seg_small_v2.sh` 
- `training\hpc_scripts\regular\launch_seg_small_v2_gpuv100.sh` 
- `training\hpc_scripts\regular\launch_seg_v2_all_9_experiments.sh` 
- `training\hpc_scripts\regular\launch_seg_v2_all_9_wide_shallow_experiments.sh` 
- `training\hpc_scripts\regular\run_train_diff_seg_small_v2.sh` 
- `training\hpc_scripts\vae\run_train_vae_clip_v2.sh` 
 
